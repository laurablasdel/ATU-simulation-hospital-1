ATU Simulation Hospital v19

Barcode sheet scan-spacing update:
- Medication labels are now printed 2 across instead of 3 across.
- More horizontal and vertical space separates neighboring barcodes.
- Each medication barcode has its own padded white scan zone.
- Medication names remain clearly printed above each barcode.
- The larger spacing is intended to reduce accidental scanning of an adjacent barcode.
- All previous v18 features are retained.
