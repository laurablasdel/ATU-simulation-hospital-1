ATU Simulation Hospital v12 — Allergy Override

- Allergy conflicts trigger a red warning dialog.
- Student may choose No — Cancel or Yes — Continue.
- Continuing documents an allergy override acknowledgment.
- Amelia Sung can receive Ampicillin in the intended simulation after acknowledging the penicillin-allergy warning.
- MAR-first layout and barcode verification remain.
